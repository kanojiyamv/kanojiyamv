/*-------------------------------------------------------*/
1.
This Program was build in IntellijIdea(ide) using Swings Concept.

This Project will help you get a handle on consumer debt.
The Consumer Loan Assistant Project computes payments and loan terms given balance and interest information.

You input a loan balance and yearly interest rate.
You then have two options: 
(1) enter the desired number of payments and the loan assistant computes the monthly payment, or 
(2) enter the desired monthly payment and the loan assistant.
determines the number of payments you will make.
An analysis of your loan, including total of payments and interest paid is also provided.

The finished project is saved as Consumer_Loan_Assistant

/*-------------------------------------------------------*/
2.
